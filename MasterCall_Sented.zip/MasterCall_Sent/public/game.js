const gameRef = firebase.database().ref("Game");
const UserRef = firebase.database().ref("users");
// const cells = document.querySelectorAll('td');
var turnObject = document.getElementById('currentPlay');
const nodeRef = firebase.database().ref('Game');
let UserCoin = 0;
let Userscore = 0;
var count = 0;
var win;
let currentPlayer = 'X';
let notcurrentPlayer = 'O';
let increasePointX = 0;
let increasePointO = 0;
const cells = document.querySelectorAll('td');
const skillPointX = document.getElementById("pointSkillX");
const skillPointO = document.getElementById("pointSkillO");
var btnJoinX = document.querySelector('#btnJoin-X');
var btnJoinO = document.querySelector('#btnJoin-O');
// const currentUser = firebase.auth().currentUser;
// console.log(currentUser)
// console.log('----------------------------')

document.getElementById("swapBtnX").disabled = true;
document.getElementById("swapBtnO").disabled = true;
gameRef.on("value", (snapshot) => {
  Object.keys(snapshot.val()).forEach((key) => {
    console.log(key)
    console.log(snapshot.val()[key])
    console.log(snapshot.val()[key][`user-X-email`])
  })
  getGameInfo(snapshot);
  snap = snapshot;
})

UserRef.on("value", (snapshot) => {
  getUserInfo(snapshot);
  snap = snapshot;
})

function getUserInfo(snapshot){
  const currentUser = firebase.auth().currentUser;
  snapshot.forEach((data) => {
    const userInfo = data.val();
  //   console.log("c2 : ")
    Object.keys(userInfo).forEach((key) => {
      if(userInfo[key] == currentUser.uid){
        console.log(userInfo[key][`coin`]);
        UserCoin = userInfo[key][`coin`];
        Userscore = userInfo[key][`score`];
      }
      console.log(Userscore)
    })
  })
}
// const currentUser = firebase.auth().currentUser;
// if(document.querySelector('#btnJoin-X').disabled && document.querySelector('#btnJoin-O').disabled){
//   console.log('dis')
//   cells.forEach(cell => cell.addEventListener('click', handleCellClick));
// }

// document.querySelector("#swapBtnO").addEventListener("click", removedata)
document.querySelectorAll(".btn-join").forEach((btnJoin) => btnJoin.addEventListener("click", JoinGame));

function removedata(){
    const nodeRef = firebase.database().ref('Game');

    // Delete the node using the remove() method
    nodeRef.remove()
    .then(() => {
        console.log('Node deleted successfully');
    })
    .catch((error) => {
        console.error('Error deleting node:', error);
    });
}

function JoinGame(event){
    const currentUser = firebase.auth().currentUser;
    console.log("[Join] Current user", currentUser);
    if(currentUser){
        console.log('ok')
        const btnJoinID = event.currentTarget.getAttribute("id");
        const player = btnJoinID[btnJoinID.length-1];

        const playerForm = document.getElementById(`name${player}`);
        if(playerForm.innerHTML == "Waiting for Player..."){
            let tmpID = `user-${player}-id`;
            let tmpEmail = `user-${player}-email`;
            gameRef.child("game-1").update({
                [tmpID]: currentUser.uid,
                [tmpEmail]: currentUser.email,
                [`skilpoint-${player}`]:0
                
            });

            console.log(currentUser.email + "added.");
        }
    }
    // snap.forEach((data) =>{
    //   const gameInfo = data.val();
    //   console.log("c1 : ",gameInfo)
    //   console.log("inside")
    //   Object.keys(gameInfo).forEach((key) => {
    //     switch (key) {
    //       case "user-x-email":
    //           if (gameInfo[key] == ""){
    //               let tmpEmail = "user-x-email";
    //           };
    //           break
    //       case "user-o-email":
    //           if (gameInfo[key] == "" && gameInfo["user-x-email"] != currentUser.email){
    //               let tmpEmail = "user-o-email";
    //           };
    //           break
    //     }
    //     gameRef.child("game-1").update({
    //       [tmpEmail]: currentUser.email
    //   });
    //   })
    // })
  };

function getGameInfo(snapshot){
  const currentUser = firebase.auth().currentUser;
  let numPlayers = 0;
  snapshot.forEach((data) => {
      const gameInfo = data.val();
      console.log("c2 : " + Object.keys(gameInfo));
      Object.keys(gameInfo).forEach((key) => {
        console.log(key);
          switch (key) {
              case "user-X-email":
                    if(gameInfo[key] != ""){
                      document.getElementById("btnJoin-X").disabled = true;
                    }
                    document.getElementById("nameX").innerHTML = gameInfo[key];
                    numPlayers++;
                    break;
              case "user-O-email":
                    if(gameInfo[key] != ""){
                      document.getElementById("btnJoin-O").disabled = true;
                    }
                    document.getElementById("nameO").innerHTML = gameInfo[key];
                    numPlayers++;
                    break;
          }

          if(document.querySelector('#btnJoin-X').disabled && document.querySelector('#btnJoin-O').disabled){
            // console.log('dis')
            cells.forEach(cell => cell.addEventListener('click', handleCellClick));
          }

          if (currentUser.email == gameInfo[key]){
            document.querySelector('#btnJoin-X').disabled = true;
            document.querySelector('#btnJoin-O').disabled = true;
        }

          if(key == "win"){
            console.log('win') 
             if(gameInfo[key] == 'X'){
                Swal.fire({
                  icon: 'info',
                  title: 'X Win!!',
                })
                //  alert('X wins!');
                resetGame();
             }else if(gameInfo[key] == 'O'){
              Swal.fire({
                icon: 'info',
                title: 'O Win!!',
              })
              //  alert(`O wins!`);
              resetGame();
             }else if(gameInfo[key] == 'Tie'){
              Swal.fire({
                icon: 'info',
                title: 'It Tie!!!',
              })
              //  alert(`Tie`);
              resetGame();
             }
           }
          if(key == "turn"){
            if(gameInfo[key] != ""){
              currentPlayer = gameInfo[key];
              turnObject.innerHTML = "Turn: " + currentPlayer;
              console.log("CP : ",currentPlayer)
            }
          }
          if(key == "skilpoint-X"){
            increasePointX = gameInfo[key];
          }
          if(key == "skilpoint-O"){
            increasePointO = gameInfo[key];
          }
          if(key == "table"){
            for(let i=0;i<9;i++){
              if(gameInfo[key][`cell-${i}`] != null)
              document.getElementById(`${i}`).innerHTML = gameInfo[key][`cell-${i}`]
            }
            // console.log(gameInfo[key]["cell-0"])
            // gameInfo[key].forEach((cell) =>{
            //   if(cell == `cell-${i}`){
            //     document.getElementById(`${i}`).innerHTML = gameInfo[key];

            //   }
            // })
          }
          // for(let i= 0;i<9; i++){
          //     if(`cell-${i}` == key[0]){
          //       document.getElementById(`${i}`).innerHTML = gameInfo[key];
          //     }
          //   }
      })
  })      
          skillPointX.innerHTML = "PointSkill X: " + increasePointX;
          skillPointO.innerHTML = "PointSkill O: " + increasePointO;
          notcurrentPlayer = currentPlayer === 'X' ? 'O' : 'X';
          console.log("aaaaaaaaa"+`increasePoint${currentPlayer}` +"bbbbbb" + `swapBtn${currentPlayer}`)
          
          if (eval(`increasePoint${currentPlayer}`) >= 2 && data[`user-${currentPlayer}-email`] == currentUser.email){
              document.getElementById(`swapBtn${currentPlayer}`).disabled = false;
              // alert("hi")
            }
            else{
              document.getElementById(`swapBtn${notcurrentPlayer}`).disabled = true;
            }
}

function handleCellClick(event) {
    const cell = event.target;
    gameRef.child("game-1").once("value", snapshot => {
      data = snapshot.val()
      currentUser = firebase.auth().currentUser
      id = event.currentTarget.id
      // if (data.turn === "X" && data["user-x-email"] === currentUser.email && !data["tables"][id]){
      //   ref.child("game-1").child("tables").update({
      //       [id]: data.turn
      //   })
      //   ref.child("game-1").update({
      //       turn: "O"
            
      //   })
      //   document.querySelector('#Skill-x').disabled = true;
      //   document.querySelector('#Skill-o').disabled = true;
      // }
      // else if (data.turn === "O" && data["user-o-email"] === currentUser.email && !data["tables"][id]){
      //   ref.child("game-1").child("tables").update({
      //       [id]: data.turn
      //   })
      //   ref.child("game-1").update({
      //       turn: "X"
            
      //   })
      //   document.querySelector('#Skill-o').disabled = true;
      //   document.querySelector('#Skill-x').disabled = true;
      // }
    })
    // console.log("AAA",data[`user-${currentPlayer}-email`])


    // if (increasePointO >= 2){
    //   document.getElementById("swapBtnO").disabled = false;
    // }
    // else{
    //   document.getElementById("swapBtnO").disabled = true;
    // }


    if (cell.textContent === '' && data[`user-${currentPlayer}-email`] == currentUser.email) {
      cell.textContent = currentPlayer;
      let dbcell = `cell-${cell.id}`;
      gameRef.child("game-1/table").update({
                [dbcell]: cell.textContent,
            });
    
      if (checkWin()) {
        console.log("hello")
        console.log("Who",currentPlayer)
        // alert('X wins!');
        //this guy error
        win = currentPlayer
        let dbwin = `win`;
        gameRef.child("game-1").update({
            [dbwin]: currentPlayer,
        });

        const user = firebase.auth().currentUser;
        // const emailRef = firebase.database().ref('users/' + user.uid + '/email'); 
        const coinRef = firebase.database().ref('users/' + user.uid + '/coin');
        const IDRef = firebase.database().ref('users/'+user.uid)
        
        console.log(UserCoin)
        console.log("hello2")
        console.log("Who2",win)
        if(data[`user-${win}-email`] == currentUser.email){
          // coinRef.set(parseInt(coinRef)+1)
          
          UserCoin = UserCoin + 10;
          Userscore = Userscore + 1;
          IDRef.update({
            coin: UserCoin,
            score: Userscore,
          })
          console.log(UserCoin)

        }
        // alert()
        // const scoreRef = firebase.database().ref('users/' + user.uid + '/score');
        // scoreRef.set(2);
        
        // alert('')
      } 
      else if (checkTie()) {
        let dbwin = `win`;
        gameRef.child("game-1").update({
                [dbwin]: "Tie",
            });
      } 
      else {
        // const user = firebase.auth().currentUser;   
          if(currentPlayer == 'X'){
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
            increasePointX = increasePointX + 1;
            // skillPointX.innerHTML = "PointSkill X: " + increasePointX;
            gameRef.child("game-1").update({
              [`skilpoint-X`]: increasePointX,
              [`turn`]: currentPlayer,
            });
            // turnObject.innerHTML = "Turn: " + currentPlayer;
            // ++increasePointX;
            // console.log('X :'+ increasePointX);
            // if (increasePointX >= 2){
            //   document.getElementById("swapBtnX").disabled = false;
            //   // alert("hi")
            // }
            // else{
            //   document.getElementById("swapBtnX").disabled = true;
            // }
          }
          else{
            currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
            increasePointO = increasePointO + 1;
            // skillPointO.innerHTML = "PointSkill O: " + increasePointO;
            gameRef.child("game-1").update({
              [`skilpoint-O`]: increasePointO,
              [`turn`]: currentPlayer,
            });
            // turnObject.innerHTML = "Turn: " + currentPlayer;
            // ++increasePointO;
            // console.log('O :'+increasePointO);
            // if (increasePointO >= 2){
            //   document.getElementById("swapBtnO").disabled = false;
            // }
            // else{
            //   document.getElementById("swapBtnO").disabled = true;
            // }
          }
          // console.log("CP2:", currentPlayer)
          // gameRef.child("game-1").update({
          //   [`turn`]: currentPlayer,
          // });
          // console.log("CP3:", currentPlayer)
      }
    }
  }


function checkWin() {
  const winPatterns = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
    [0, 4, 8], [2, 4, 6] // diagonals
  ];
  return winPatterns.some(pattern =>
    pattern.every(index => cells[index].textContent === currentPlayer)
  );
}
function resetGame() {
    // skillPointX.innerHTML = "PointSkill X: " + increasePointX;
    // skillPointO.innerHTML = "PointSkill O: " + increasePointO;
    // for(let i=0;i<9;i++){
    //   console.log("hello")
    //   let dbcell = `cell-${i}`;
        gameRef.child("game-1/table").update({
                ["cell-1"]: null,["cell-2"]: null,["cell-3"]: null,
                ["cell-4"]: null,["cell-5"]: null,["cell-6"]: null,
                ["cell-7"]: null,["cell-8"]: null,["cell-0"]: null,
        });
        gameRef.child("game-1").update({
          ["win"]:null,
          ["turn"]:"X",
          [`skilpoint-O`]: null,
          [`skilpoint-X`]: null,
        });
    // }
    [...cells].forEach(cell => cell.textContent = '');
    currentPlayer = 'X';
    turnObject.innerHTML = "Turn: " + currentPlayer;
    increasePointX = 0;
    increasePointO = 0;
  }
    function checkTie() {
    return [...cells].every(cell => cell.textContent !== '');
    }

  function useSkill(){
      let can = true;
      console.log('useSkill')
      const cells = document.querySelectorAll('td');
      cells.forEach(cell => {
          cell.addEventListener('click', () => {
              if (can){
                  if (currentPlayer == 'X'){
                    if(increasePointX < 2){
                      console.log("not enough sp")
                      // document.getElementById("swapBtn").disabled = true;
                    }else{
                      if (cell.textContent !== '') {
                        cell.textContent = '';
                        let dbcell = `cell-${cell.id}`;
                        gameRef.child("game-1/table").update({
                            [dbcell]: cell.textContent,
                        });
                        can = false;
                        increasePointX = increasePointX - 2;
                        gameRef.child("game-1").update({
                          [`skilpoint-X`]: increasePointX,
                        });
                        skillPointX.innerHTML = "PointSkill X: " + increasePointX;
                        console.log('useSkil remain:'+ increasePointX);
                    }
                    }
                  }
                  else{
                    if(increasePointO < 2){
                      console.log("not enough sp")
                      // document.getElementById("swapBtn").disabled = true;
                    }else{
                      if (cell.textContent !== '') {
                        cell.textContent = '';
                        let dbcell = `cell-${cell.id}`;
                        gameRef.child("game-1/table").update({
                            [dbcell]: cell.textContent,
                        });
                        can = false;  
                        increasePointO = increasePointO - 2;
                        gameRef.child("game-1").update({
                          [`skilpoint-O`]: increasePointO,
                        });
                        skillPointO.innerHTML = "PointSkill O: " + increasePointO;
                        console.log('useSkil remain' + increasePointO);
                    }
                    }
                  }
              }
              
              
              // swapBtn.disabled = true;
          });
      });
  }
   

function useRandom(){
  let can = true;
  const boxes = document.querySelectorAll('td')
  console.log('useRandom')
  const emptyBoxes = Array.from(boxes).filter(box => box.textContent != '');
  console.log(emptyBoxes.length)
			if (emptyBoxes.length < 9) {
        if (can){
          if(increasePointO < 1){
          console.log("not enough sp")
          // document.getElementById("swapBtn").disabled = true;
          }
          else{
            const randomBox = emptyBoxes[Math.floor(Math.random() * emptyBoxes.length)];
            console.log("box",randomBox.id)				
            randomBox.textContent = null;
            let ranCell = `cell-${randomBox.id}`;
            gameRef.child("game-1/table").update({
              [ranCell] : randomBox.textContent,
            });
            // can = false;
          }
        }
        
				
    }
  }
  
// function tutorial(){
//   Swal.fire({
//     title: 'How to play',
//     text: 'Rule is same as simple Tic Tac Toe but increase skill',
//     imageUrl: 'https://unsplash.it/400/200',
//     imageWidth: 400,
//     imageHeight: 200,
//     imageAlt: 'Custom image',
//     showCancelButton: true,
//     confirmButtonColor: '#3085d6',
//     cancelButtonColor: '#d33',
//     cancelButtonText: 'canm',
//     confirmButtonText: 'Yes, delete it!'
//   }).then((result) => {
//     if (result.isConfirmed) {
//       Swal.fire(
//         'Deleted!',
//         'Your file has been deleted.',
//         'success'
//       )
//     }
//     if (result.isDenied) {
//       Swal.fire(
//         'Deleted!',
//         'Your file has been deleted.',
//         'success'
//       )
//     }
//   })
//   }

  
// window.onload = tutorial();