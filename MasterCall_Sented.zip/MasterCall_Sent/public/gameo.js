const cells = document.querySelectorAll('td');
let currentPlayer = 'X';
var turnObject = document.getElementById('currentPlay');
var increasePointX = 0;
var increasePointO = 0;

document.getElementById("swapBtnX").disabled = true;
document.getElementById("swapBtnO").disabled = true;

console.log('------------------------')
function handleCellClick(event) {
  const cell = event.target;
  
  if (cell.textContent === '') {
    cell.textContent = currentPlayer;
    if (checkWin()) {
      
      alert(`${currentPlayer} wins!`);
      // alert()
      // const scoreRef = firebase.database().ref('users/' + user.uid + '/score');
      // scoreRef.set(2);
      resetGame();
      
      // alert('')
    } else if (checkTie()) {
      alert(`It's a tie!`);
      resetGame();
    } else {
      // currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
      // turnObject.innerHTML = "Turn: " + currentPlayer;
      console.log(currentPlayer)
        if(currentPlayer == 'X'){
          currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
          turnObject.innerHTML = "Turn: " + currentPlayer;
          ++increasePointX;
          console.log('X :'+ increasePointX);
          skillPointX.innerHTML = "PointSkill X: " + increasePointX;
          if (increasePointX >= 2){
            document.getElementById("swapBtnX").disabled = false;
            // alert("hi")
          }
          else{
            document.getElementById("swapBtnX").disabled = true;
          }
        }
        else{
          currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
          turnObject.innerHTML = "Turn: " + currentPlayer;
          ++increasePointO;
          console.log('O :'+increasePointO);
          skillPointO.innerHTML = "PointSkill O: " + increasePointO;
          if (increasePointO >= 2){
            document.getElementById("swapBtnO").disabled = false;
          }
          else{
            document.getElementById("swapBtnO").disabled = true;
          }
        }
    }
  }
}

function checkWin() {
  const winPatterns = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
    [0, 4, 8], [2, 4, 6] // diagonals
  ];
  return winPatterns.some(pattern =>
    pattern.every(index => cells[index].textContent === currentPlayer)
  );
}

function checkTie() {
  return [...cells].every(cell => cell.textContent !== '');
}

function resetGame() {
  [...cells].forEach(cell => cell.textContent = '');
  currentPlayer = 'X';
  turnObject.innerHTML = "Turn: " + currentPlayer;
  increasePointX = 0;
  increasePointO = 0;
  skillPointX.innerHTML = "PointSkill X: " + increasePointX;
  skillPointO.innerHTML = "PointSkill O: " + increasePointO;
}

cells.forEach(cell => cell.addEventListener('click', handleCellClick));

function useSkill(){
    let can = true;
    console.log('useSkill')
    const cells = document.querySelectorAll('td');
    cells.forEach(cell => {
        cell.addEventListener('click', () => {
            if (can){
                if (currentPlayer == 'X'){
                  if(increasePointX < 2){
                    console.log("not enough sp")
                    // document.getElementById("swapBtn").disabled = true;
                  }else{
                    if (cell.textContent !== '') {
                      cell.textContent = '';
                      can = false;
                      increasePointX = increasePointX - 2;
                      skillPointX.innerHTML = "PointSkill X: " + increasePointX;
                      console.log('useSkil remain:'+ increasePointX);
                  }
                  }
                }
                else{
                  if(increasePointO < 2){
                    console.log("not enough sp")
                    // document.getElementById("swapBtn").disabled = true;
                  }else{
                    if (cell.textContent !== '') {
                      cell.textContent = '';
                      can = false;
                      increasePointO = increasePointO - 2;
                      skillPointO.innerHTML = "PointSkill O: " + increasePointO;
                      console.log('useSkil remain' + increasePointO);
                     
                  }
                  }
                }
            }
            
            
            // swapBtn.disabled = true;
        });
    });
}

const skillPointX = document.getElementById("pointSkillx");
const skillPointO = document.getElementById("pointSkillo");



// const cells = document.querySelectorAll('.cell');
// function useSkill(){
//     swapBtn.addEventListener('click', () => {
//         const tempMark = currentPlayer.mark;
//         currentPlayer.mark = otherPlayer.mark;
//         otherPlayer.mark = tempMark;
//         swapBtn.disabled = true; // Disable the swap button after it's used
//       });
// }
