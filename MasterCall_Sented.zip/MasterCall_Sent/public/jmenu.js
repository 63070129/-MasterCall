var Btn_set = document.querySelector('.Btn');

function PlayHandle(){
    Btn_set = ``
}